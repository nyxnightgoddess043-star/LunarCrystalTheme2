# Lunar Crystal Theme (Android)

A starter Android Studio project inspired by the purple anime image supplied in the conversation.

## Features
- Portrait wallpaper preview with a live local time/date label
- One-tap action to set the supplied image as the device wallpaper
- Home-screen clock/date widget: `Lunar Crystal Clock`
- Crystal-purple visual styling and icon-style preview

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

The APK is not precompiled in this delivery environment. This is the editable Android Studio source project.

## Add the clock widget
After installing the app, long-press an empty area of the Android home screen, choose **Widgets**, find **Lunar Crystal Clock**, and drag it onto the screen.

## Notes
- Android launchers control actual home-screen icon replacement. The app includes a visual icon preview; full launcher-wide icon replacement needs a compatible icon pack/launcher integration.
- Weather and music widgets are not connected to live services in this starter version.

## Optional cloud build
The `.github/workflows/build-apk.yml` workflow can build a debug APK on GitHub Actions after the project is uploaded to a GitHub repository. In the repository, open **Actions**, run **Build Lunar Crystal Theme APK** (or push to `main`), then download the `Lunar-Crystal-Theme-debug-apk` artifact from the workflow run. This workflow is a convenience, not a prebuilt APK.
