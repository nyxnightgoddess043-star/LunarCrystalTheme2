package com.lunarcrystal.theme;

import android.app.Activity;
import android.app.WallpaperManager;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17, 10, 44));
        getWindow().setNavigationBarColor(Color.rgb(17, 10, 44));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(24));
        page.setBackgroundColor(Color.rgb(14, 9, 35));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("☾  LUNAR CRYSTAL");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.BOLD));
        title.setGravity(Gravity.CENTER);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Tema ungu • bulan • kristal • bintang");
        subtitle.setTextColor(Color.rgb(213, 193, 255));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = matchWrap();
        subP.bottomMargin = dp(16);
        page.addView(subtitle, subP);

        FrameLayout preview = new FrameLayout(this);
        preview.setBackground(roundBg(0xFF21144F, 0xFF8C6BFF, 24));
        preview.setClipToOutline(true);
        ImageView wallpaper = new ImageView(this);
        wallpaper.setImageResource(R.drawable.lunar_wallpaper);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout shade = new LinearLayout(this);
        shade.setOrientation(LinearLayout.VERTICAL);
        shade.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        shade.setPadding(dp(14), dp(18), dp(14), dp(12));
        shade.setBackgroundColor(0x44200C55);
        FrameLayout.LayoutParams shadeP = new FrameLayout.LayoutParams(-1, -1);
        preview.addView(shade, shadeP);

        TextView time = new TextView(this);
        time.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        time.setTextColor(Color.WHITE);
        time.setTextSize(38);
        time.setTypeface(Typeface.create("serif", Typeface.NORMAL));
        shade.addView(time);

        TextView date = new TextView(this);
        date.setText(new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(new Date()));
        date.setTextColor(0xFFF0E8FF);
        date.setTextSize(12);
        shade.addView(date);

        TextView quote = new TextView(this);
        quote.setText("✦  Bintang tetap bersinar\nmeski malam paling gelap  ✦");
        quote.setGravity(Gravity.CENTER);
        quote.setTextColor(Color.WHITE);
        quote.setTextSize(13);
        quote.setShadowLayer(8, 0, 0, 0xFF9D7BFF);
        LinearLayout.LayoutParams qp = matchWrap();
        qp.topMargin = dp(10);
        shade.addView(quote, qp);

        LinearLayout mockDock = new LinearLayout(this);
        mockDock.setGravity(Gravity.CENTER);
        mockDock.setOrientation(LinearLayout.HORIZONTAL);
        String[] glyphs = {"✿", "✧", "☾", "✦"};
        for (String glyph : glyphs) {
            TextView icon = new TextView(this);
            icon.setText(glyph);
            icon.setTextColor(Color.WHITE);
            icon.setTextSize(22);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(roundBg(0xBB35216E, 0xFFD9C2FF, 50));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(44), dp(44));
            ip.setMargins(dp(6), 0, dp(6), 0);
            mockDock.addView(icon, ip);
        }
        LinearLayout.LayoutParams dockP = new LinearLayout.LayoutParams(-1, -2);
        dockP.gravity = Gravity.BOTTOM;
        dockP.topMargin = dp(230);
        shade.addView(mockDock, dockP);

        LinearLayout.LayoutParams previewP = new LinearLayout.LayoutParams(-1, dp(440));
        previewP.bottomMargin = dp(18);
        page.addView(preview, previewP);

        TextView section = new TextView(this);
        section.setText("PRATINJAU TEMA");
        section.setTextColor(0xFFE4D8FF);
        section.setTextSize(13);
        section.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams secP = matchWrap();
        secP.bottomMargin = dp(10);
        page.addView(section, secP);

        Button apply = button("Pasang wallpaper");
        apply.setOnClickListener(v -> setWallpaper());
        page.addView(apply, matchWrap());

        Button info = button("Cara menambahkan widget jam");
        LinearLayout.LayoutParams infoP = matchWrap();
        infoP.topMargin = dp(10);
        page.addView(info, infoP);
        info.setOnClickListener(v -> Toast.makeText(this,
            "Tekan lama area kosong di layar utama → Widget → Lunar Crystal Clock → seret ke layar.", Toast.LENGTH_LONG).show());

        TextView note = new TextView(this);
        note.setText("Ikon di pratinjau adalah dekorasi visual. Untuk mengganti ikon aplikasi asli, gunakan launcher Android yang mendukung paket ikon.");
        note.setTextColor(0xFFB8ACD8);
        note.setTextSize(12);
        LinearLayout.LayoutParams noteP = matchWrap();
        noteP.topMargin = dp(14);
        page.addView(note, noteP);

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }

    private GradientDrawable roundBg(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setBackground(roundBg(0xFF6041B8, 0xFFD9C2FF, 18));
        return b;
    }

    private void setWallpaper() {
        try {
            WallpaperManager manager = WallpaperManager.getInstance(this);
            manager.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.lunar_wallpaper));
            Toast.makeText(this, "Wallpaper berhasil dipasang.", Toast.LENGTH_LONG).show();
        } catch (IOException | SecurityException e) {
            Toast.makeText(this, "Tidak bisa memasang wallpaper pada perangkat ini.", Toast.LENGTH_LONG).show();
        }
    }
}
